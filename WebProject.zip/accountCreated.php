<?php
	echo "Account Created!";
	echo '<br></br><a href="login.html">Please Login Here</a>';
?>